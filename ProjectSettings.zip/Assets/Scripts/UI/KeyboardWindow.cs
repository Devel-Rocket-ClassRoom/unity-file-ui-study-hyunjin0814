using UnityEngine;
using UnityEngine.UI;

public class KeyboardWindow : GenericWindow
{
    public Button cancleButton;
    public Button deleteButton;
    public Button acceptButton;

    private void Awake()
    {
        cancleButton.onClick.AddListener(OnCancle);
        deleteButton.onClick.AddListener(OnDelete);
        acceptButton.onClick.AddListener(OnAccept);    
    }

    public override void Open()
    {
        base.Open();
    }

    public override void Close()
    {
        base.Close();
    }

    public void OnCancle()
    {

    }

    public void OnDelete()
    {
        windowManager.Open(0);
    }

    public void OnAccept()
    {
        windowManager.Open(1);
    }
}
